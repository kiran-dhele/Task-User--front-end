import { Component, NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { DashboardComponent } from './dashboard/dashboard.component';
import { Component1Component } from './module/module1/component1/component1.component';
import { Component2Component } from './module/module1/component2/component2.component';
import { Component3Component } from './module/module1/component3/component3.component';
import { UpdateUserComponent } from './module/module1/update-user/update-user.component';


const routes: Routes = [
  {path:"", redirectTo:"dashboard", pathMatch:"full"},
  {path:"dashboard", component:DashboardComponent},
  {path:"dashboard/register", component:Component1Component},
  {path:"dashboard/view/:input", component:Component2Component},
  {path:"dashboard/allUsers/:input", component:Component3Component},
  {path:"dashboard/allUsers/userByJoiningDate/update", component:UpdateUserComponent},
  {path:"dashboard/allUsers/userByDOB/update", component:UpdateUserComponent},
  {path:"dashboard/view/update", component:UpdateUserComponent}

  
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
