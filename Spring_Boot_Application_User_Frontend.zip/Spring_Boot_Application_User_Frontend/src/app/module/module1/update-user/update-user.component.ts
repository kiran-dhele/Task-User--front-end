import { Location } from '@angular/common';
import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { User } from 'src/app/model/user';
import { Service1Service } from 'src/app/shared/service1.service';

@Component({
  selector: 'app-update-user',
  templateUrl: './update-user.component.html',
  styleUrls: ['./update-user.component.css']
})
export class UpdateUserComponent implements OnInit {

  constructor(private fb:FormBuilder, private location:Location, private cs:Service1Service) { }
updateForm:FormGroup
user:any
  ngOnInit() {
    this.updateForm=this.fb.group({
      id:['', Validators.required],
      name:['', Validators.required],
      surname:['',Validators.required],
      dob:['',Validators.required],
      city:[Validators.required],
      pincode:['',Validators.required],
      mobileNo:['',[Validators.required, Validators.pattern("(0/91)?[7-9][0-9]{9}")]],
      panNo:['',Validators.required],
      joiningDate:['',Validators.required],
      salary:['',Validators.required]
    })
    this.existingData();
  }

  existingData()
  {
   this.user=  this.location.getState();
   console.log(this.user.id);
   console.log(this.user.dob);

   this.updateForm.get('id').setValue(this.user.id);
   this.updateForm.get('name').setValue(this.user.name);
   this.updateForm.get('surname').setValue(this.user.surname);
   this.updateForm.get('dob').setValue(this.user.dob);
   this.updateForm.get('city').setValue(this.user.city);
   this.updateForm.get('pincode').setValue(this.user.pincode);
   this.updateForm.get('mobileNo').setValue(this.user.mobileNo);
   this.updateForm.get('panNo').setValue(this.user.panNo);
   this.updateForm.get('joiningDate').setValue(this.user.joiningDate);
   this.updateForm.get('salary').setValue(this.user.salary);

  }

  updateUser()
  {
      console.log(this.updateForm.value);
      this.cs.updateUser(this.updateForm.value).subscribe();
      this.location.back();
  }

}
