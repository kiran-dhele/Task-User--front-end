import { Location } from '@angular/common';
import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { User } from 'src/app/model/user';
import { Service1Service } from 'src/app/shared/service1.service';

@Component({
  selector: 'app-component1',
  templateUrl: './component1.component.html',
  styleUrls: ['./component1.component.css']
})
export class Component1Component implements OnInit {

  constructor(private fb:FormBuilder, private cs:Service1Service, private location:Location) { }

  regForm:FormGroup;
  ngOnInit() {

    this.regForm=this.fb.group({
      name:['',Validators.required],
      surname:['',Validators.required],
      city:['',Validators.required],
      pincode:['',Validators.required],
      mobileNo:['',[Validators.required,Validators.pattern("(0/91)?[7-9][0-9]{9}")]],
      dob:['',Validators.required],
      joiningDate:['',Validators.required],
      panNo:['',Validators.required],
      salary:['',Validators.required]

    })
  }
  regObj:any
  registerUser()
  {
    //this.regObj=this.regForm;
    console.log(this.regForm);
    this.cs.registerUser(this.regForm.value).subscribe();
    this.location.back();
  }
}
