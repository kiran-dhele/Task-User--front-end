import { Location } from '@angular/common';
import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { User } from 'src/app/model/user';
import { Service1Service } from 'src/app/shared/service1.service';

@Component({
  selector: 'app-component3',
  templateUrl: './component3.component.html',
  styleUrls: ['./component3.component.css']
})
export class Component3Component implements OnInit {

  constructor(private cs:Service1Service, private location:Location, private routes:ActivatedRoute) { }
  
  users:User[]
  ngOnInit() {

  this.sortUser();
}

sortUser()
{
  let sortInput:any=this.routes.snapshot.paramMap.get('input');

  
      this.cs.sortUser(sortInput).subscribe((data:User[]) => 
      {
        this.users=data;
      }
      )
   
}

  deleteUser(id:number)
  {
    console.log(id);
    this.cs.deleteUser(id).subscribe();
    window.location.reload();
  }

  hardDeleteUser(id:number)
  {
    this.cs.hardDeleteUser(id).subscribe();
    window.location.reload();
  }
}
