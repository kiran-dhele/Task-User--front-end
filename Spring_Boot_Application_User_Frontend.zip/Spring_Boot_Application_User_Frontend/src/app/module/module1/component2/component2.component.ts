import { Location } from '@angular/common';
import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { User } from 'src/app/model/user';
import { Service1Service } from 'src/app/shared/service1.service';

@Component({
  selector: 'app-component2',
  templateUrl: './component2.component.html',
  styleUrls: ['./component2.component.css']
})
export class Component2Component implements OnInit {

  constructor(private cs:Service1Service, private location:Location, private routes:ActivatedRoute) { }
  //input:any
  users:User[]
  
  ngOnInit() {
    console.log(this.routes.snapshot.paramMap.get('input'));
   this. sortUser();
  }

  sortUser()
  {
    //this.input=this.location.getState();
    let input:any=this.routes.snapshot.paramMap.get('input');
    console.log(input)
    
        this.cs.searchUser(input).subscribe((data:any[]) =>
    {
      this.users=data;
    }
    )
      
  }

  deleteUser(id:number)
  {
    console.log(id);
    this.cs.deleteUser(id).subscribe();
    window.location.reload();  
  }
  hardDeleteUser(id:number)
  {
    this.cs.hardDeleteUser(id).subscribe();
    window.location.reload();
  }
}
