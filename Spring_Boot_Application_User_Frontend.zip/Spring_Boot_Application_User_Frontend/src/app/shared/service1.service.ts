import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { User } from '../model/user';

@Injectable({
  providedIn: 'root'
})
export class Service1Service {

  constructor(private http:HttpClient) { }

  registerUser(user:any)
  {
    console.log(user);
    return this.http.post("http://localhost:8080/registerUser",user);
  }

  searchUser(input:any)
  {
    console.log(input);
    return this.http.get("http://localhost:8080/findUser"+"/"+input);
  }

  sortUser(sortInput:any):Observable<User[]>
  {
    console.log(sortInput)
    return this.http.get<User[]>("http://localhost:8080"+"/"+sortInput);
  }

  deleteUser(id:number)
  {
    return this.http.delete("http://localhost:8080/softDeleteUser"+"/"+id);
  }

  updateUser(user:any)
  {
    return this.http.put("http://localhost:8080/editUser",user)
  }

  hardDeleteUser(id:number)
  {
    return this.http.delete("http://localhost:8080/deleteUser"+"/"+id);
  }
}
