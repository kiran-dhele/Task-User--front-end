export class User {
	name:any;
	surname:any;
	city:any;
	pincode:any;
	mobileNo:any;
	dob:any;
	joiningDate:any;
	panNo:any;
	salary:any;
}
